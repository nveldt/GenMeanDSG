f = readlines(homedir()*"/data/Facebook100/Facebook_Sets.txt")
graphs = split(f[1]) 

##  Try something else

P1 = plot(grid = false, legend = false)
P2 = plot(grid = false, legend = false)
P3 = plot(grid = false, legend = false)
P4 = plot(grid = false, legend = false)
P5 = plot(grid = false, legend = false)
P6 = plot(grid = false, legend = false)

counter = 0
Spec = Vector{Int64}()
for j = 1:100
    global counter, lab
    ms = 4
    lw = 1.5
graph =graphs[j]
println("$j $graph")
F = matread(homedir()*"/data/Facebook100/$graph.mat")
A = F["A"]
n = size(A,1)
# P = collect(0.5:0.5:4)
M = matread("fb_output/$(graph)_output_p2.mat")
P = M["P"]
Ssets = M["Ssets"]
Times = M["Times"]
Ranks = M["Ranks"]
Objectives = M["Objectives"]
Sizes = vec(sum(Ssets,dims = 1))
mdegs = zeros(8)
m2 = zeros(8)
maxs = zeros(8)
vars = zeros(8)
mins = zeros(8)
dens = zeros(8)
for i = 1:8
    S = findall(x->x>0,Ssets[:,i])
    As = A[S,S]
    edges = sum(As)/2
    posedges = binomial(length(S),2)
    dens[i] = edges/posedges
    ds = vec(round.(Int64,sum(As,dims = 2)))
    mdegs[i] = StatsBase.mean(ds)
    m2[i] = StatsBase.mean(ds.^2)
    mins[i] = minimum(ds)
    maxs[i] = maximum(ds)
    vars[i] = StatsBase.var(ds)
end

lab = ""
if true #Sizes[end] > 1.5*Sizes[4]
    color = :green

plot!(P1,P,mdegs,color = color, alpha = 0.5, xlabel = "p",ylabel = lab,title = "mean")
plot!(P2,P,mins,color = color, alpha = 0.5, xlabel = "p",ylabel = lab,title = "min")
plot!(P3,P,maxs,color = color, alpha = 0.5, xlabel = "p",ylabel = lab,title = "max")
plot!(P4,P,dens,color = color, alpha = 0.5, xlabel = "p",ylabel = lab,title = "edge density")
plot!(P5,P,m2,color = color, alpha = 0.5, xlabel = "p",ylabel = lab,title = "mean (d2)")
plot!(P6,P,Sizes,color = color, alpha = 0.5, xlabel = "p",ylabel = lab,title = "sizes")
end
end

## plts

# plot!(P1)
# savefig("fb_figures/Facebook_$(lab)_large.pdf")
