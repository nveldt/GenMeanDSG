## Explore more
f = readlines(homedir()*"/data/Facebook100/Facebook_Sets.txt")
graphs = split(f[1])

"""
Here we're checking when we get better results by running p not equal to 1,
for the p = 1 objective.
"""

counter = 0
Better = Vector{Int64}()
P1 = plot(grid = false)
Densities0 = zeros(100,3)
Densities1 = zeros(100,3)
Densities2 = zeros(100,3)
for g = 1:100
    global counter
    graph = graphs[g]
    F = matread(homedir()*"/data/Facebook100/$graph.mat")
    A = F["A"]
    local_info = round.(Int64,F["local_info"])
    n = size(A,1)
    M = matread("fb_output/$(graph)_output_pnear1.mat")
    P = vec(M["P"])
    Ssets = M["Ssets"]
    Times = M["Times"]
    Ranks = M["Ranks"]
    Objectives = M["Objectives"]
    Sizes = vec(sum(Ssets,dims = 1))
    jj = length(P)
    m1 = zeros(jj)
    m2 = zeros(jj)
    m0 = zeros(jj)
    for i = 1:jj
        S = findall(x->x>0,Ssets[:,i])
        As = A[S,S]
        ds = vec(round.(Int64,sum(As,dims = 2)))
        m1[i] = mean(ds)
        m0[i] = mean(ds.^P[1])
        m2[i] = mean(ds.^P[3])
    end

    if m1[1] > m1[2] || m1[3] > m1[2]
        println("$i $graph")
        @show m1 .- m1[2]
        counter += 1
        push!(Better,i)
    end

    Densities0[g,:] = m0
    Densities1[g,:] = m1
    Densities2[g,:] = m2

end
