M = matread(homedir()*"/data/TripAdvisor-UIUC-hypergraphs/tripadvisor_H.mat")
H = M["H"]
Hall = M["H_all"]
w = M["weights"]
l_country = M["label_country"]


## Need to turn this into a graph

A = Hall'*Hall
n = size(H,2)
for i = 1:n
    A[i,i] = 0
end
A = sparse(A)
I,J,V = findnz(A)
delta = 0
inds = findall(x->x>delta,V)
As = sparse(I[inds],J[inds],ones(length(inds)),n,n)
length(As.nzval)/n^2
A = As

## Explore more
M = matread("Output2/tripadvisor_output.mat")
Ssets = M["Ssets"]
Times = M["Times"]
Ranks = M["Ranks"]
Objectives = M["Objectives"]
P = M["P"]

## Plot stuff


Sizes = vec(sum(Ssets,dims = 1))
ch = changetracker2(Ssets,2)
plot(P,ch)


## degree plots

degs = zeros(8)
mx = zeros(8)
vari = zeros(8)
meds = zeros(8)
mins = zeros(8)
for i = 1:8
    S = findall(x->x>0,Ssets[:,i])
    yS = L[S]
    As = A[S,S]
    ns = length(S)
    ds = vec(round.(Int64,sum(As,dims = 2)))
    println("$(P[i]) \t $ns")
    pm = sortperm(vec(ds),rev = true)
    @show ds[pm[1:10]]
    # pm2 = sortperm(vec(ds))
    # @show ds[pm2[1:10]]
    degs[i] = mean(ds)
    meds[i] = StatsBase.median(ds)
    mx[i] = maximum(ds)
    vari[i] = StatsBase.var(ds)
    mins[i] = minimum(ds)
end

@show sum(Ssets,dims = 1)
plot(1:8,vari,legend = false)

# % Cat1 = local_info(:,1); % student-faculty flag
# % Cat2 = local_info(:,2); % gender
# % Cat3 = local_info(:,3); % major
# % Cat4 = local_info(:,4); % 2nd major
# % Cat5 = local_info(:,5); % dorm/residence
# % Cat6 = local_info(:,6); % Year
# % Cat7 = local_info(:,7); % high school

## count

D =  countmap(local_info[:,5])

function topk(D,top)
    K = keys(D)
    k = maximum(K)
    E = zeros(k)
    for key in K
        if key > 0
            E[key] = D[key]
        end
    end

    pm = sortperm(E, rev = true)

    if length(pm) <= top
        return pm
    else
        return pm[1:top]
    end

end
