## Load something
include("pdenalgs.jl")

gname = "polbooksA.mat"
# gname = "KarateA.mat"
# gname = "lesmisA.mat"
# gname = "dolphinsA.mat"
# names = ["caHepPhA.mat","ca-AstroPhA.mat"]
#
#  gname = names
G = matread(homedir()*"/data/Graph-Collections/Graphs/"*gname)
A = G["A"]

## run it
dicty = false
p = 1.1

n = size(A,1)
S = collect(1:n)    # current set of nodes in local graph, in order
sizeS = n           # size of local graph
d = sum(A,dims = 1)
if dicty
    d2 = Dict{Int64,Int64}()
    for i = 1:n
        d2[i] = d[i]
    end
    d = d2
end

numerator = sum(d.^p)

bestObj = numerator/sizeS
bestS = S
ranking = zeros(Int64,n)

cp = A.colptr
row = A.rowval
AdjList = Vector{Vector{Int64}}()
for i = 1:n
    push!(AdjList,row[cp[i]:cp[i+1]-1])
end

D = zeros(n)
for i = 1:n
    D[i] = d[i]^p
    for k = AdjList[i]
        D[i] += d[k]^p - (d[k]-1)^p
    end
end
dorig = d
A1 = deepcopy(AdjList)
# get the minimum value
order = Vector{Int64}()
d = copy(dorig)
H = MutableBinaryMinHeap(D)
numer = sum(d.^p)
Objs = zeros(n+1)
Objs[1] = numer/n
next = 2
denom = n-1

S = collect(1:n)
Del = getdeltas_naive(A,S,p)

# now
while ~isempty(H)
    global numer, denom,next,S, Del
    # @assert(length(Del)==length(S))

    v, i = top_with_handle(H)
    # v2, i2_local = findmin(Del)
    # i2 = S[i2_local]
    # S = setdiff(S,i)
    # if v2 < v
    #     @show next, v2, v, i, i2
    #     @show H[i], H[i2]
    #     break
    # end
    # i = i2
    push!(order,i)
    pop!(H)
    Ni = AdjList[i]                     # Neighbors of node i
    AdjList[i] = Vector{Int64}()        # delete the existece of i, I think this part is unnecessary

    # d[Ni] .-= 1
    di = d[i]
    if di > 0
        dichange = di^p - (di-1)^p
        d[i] = 0
        numer -= di^p
        # Remove this from its neighbors list
        for nb = Ni
            removej!(AdjList[nb],i)                         # This is no longer a neighboring node, we're removed it
            Old = H[nb]                                     # previous value of D[nb]
            New = Old - d[nb]^p + (d[nb]-1)^p - dichange    # new value now that node i is gone
            update!(H,nb,New)                               # update the heap
            numer -= d[nb]^p-(d[nb]-1)^p
            d[nb] -= 1                                      # decrease degree
        end

        # At this point, we have made all changes due to node i disappearing.
        # Now we need to account for changes in D/H
        # that are due to changes in the degree for i's neighbors
        for b = Ni
            db = d[b]
            dichange = (db+1)^p - (db)^p
            Nb = AdjList[b]
            for k in Nb
                Old = H[k]
                New = Old + db^p - (db-1)^p - dichange
                update!(H,k,New)
            end
        end
    end

    # Nah
    # if d[i] > 0
    #     d[i] = 0
    #
    #     for nb = Ni
    #         New = d[nb].^p
    #         removej!(AdjList[nb],i)
    #         for k in AdjList[nb]
    #             New += d[k]^p - (d[k]-1)^p
    #         end
    #         update!(H,nb,New)
    #     end
    # end

    # if di > 0
    #     dichange = di^p - (di-1)^p
    #     d[i] = 0
    #     numer -= di^p
    #     # Remove this from its neighbors list
    #     for nb = Ni
    #         removej!(AdjList[nb],i)                         # This is no longer a neighboring node, we're removed itå
    #         Old = H[nb]                                     # previous value of D[nb]
    #         New = Old - d[nb]^p + (d[nb]-1)^p - dichange    # new value now that node i is gone
    #         update!(H,nb,New)                               # update the heap
    #         numer -= d[nb]^p-(d[nb]-1)^p
    #         d[nb] -= 1                                      # decrease degree
    #     end
    # end


    numer = sum(d.^p)
    Objs[next] = numer/denom
    denom -= 1
    next +=1
    Del = getdeltas_naive(A,S,p)

end
Objs[end] = 0





## check more
S1, objS1,ranking1 = pgreedy_naive(A,p)
pm = maximum(Objs)
objS1
