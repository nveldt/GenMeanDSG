using MAT

M = matread("Datasets/Amazon_14.mat")
H = M["H"]
L = M["labels"]
m,n = size(H)
A = [spzeros(m,m) H; H' spzeros(n,n)]

Products = collect(m+1:m+n)
Reviewers = collect(1:n)

## clique
A = H'*H
n = size(H,2)
for i = 1:n
    A[i,i] = 0
end
A = sparse(A)
I,J,V = findnz(A)
delta = 1
inds = findall(x->x>delta,V)
As = sparse(I[inds],J[inds],ones(length(inds)),n,n)
length(As.nzval)/length(A.nzval)
A = As
## new try
n = size(A,1)
P = [1, 1.05]
Ssets = zeros(n,length(P))
Times = zeros(length(P))
Ranks = zeros(n,length(P))
Objectives = zeros(n,length(P))
for i = 1:length(P)
    p = P[i]
    tic = time()
    S, objS, Objs, ranking = GenPeel(A,p)
    timers = time()-tic
    Times[i] = timers
    Ssets[S,i] .= 1
    Objectives[:,i] = Objs
    Ranks[:,i] = ranking
    nS = length(S)
    println("$p \t $nS \t $objS \t $timers")

    matwrite("Output2/Amazon14_output_near1.mat",Dict("Ssets"=>Ssets,"P"=>P,
            "Ranks"=>Ranks,"Times"=>Times,"Objectives"=>Objectives))
end



## Stats me
jj = length(P)
degs = zeros(jj)
m2 = zeros(jj)
mx = zeros(jj)
vari = zeros(jj)
meds = zeros(jj)
mins = zeros(jj)
numP = zeros(jj)
numR =zeros(jj)
for i = 1:jj
    S = findall(x->x>0,Ssets[:,i])
    Sp = intersect(S,Products)
    Sr = intersect(S,Reviewers)
    numP[i] = length(Sp)
    numR[i] = length(Sr)
    # yS = L[S]
    As = A[S,S]
    ns = length(S)
    ds = vec(round.(Int64,sum(As,dims = 2)))
    println("$(P[i]) \t $ns")
    pm = sortperm(vec(ds),rev = true)
    @show ds[pm[1:10]]
    degs[i] = mean(ds)
    m2[i] = mean(ds.^2)
    meds[i] = StatsBase.median(ds)
    mx[i] = maximum(ds)
    vari[i] = StatsBase.var(ds)
    mins[i] = minimum(ds)
end


## Plots
Sizes = vec(sum(Ssets,dims = 1))
plot(P,numP,legend = false, grid = false, color = :green)
plot!(P,numR,color = :blue)
plot!(P,Sizes, color = :red)
## Peel

S, density, degeneracy, maxcore, Objs, ranking, degrees = SimplePeel(A)

CoreP = intersect(maxcore,Products)
CoreR = intersect(maxcore,Reviewers)
