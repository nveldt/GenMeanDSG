## Explore more
f = readlines(homedir()*"/data/Facebook100/Facebook_Sets.txt")
graphs = split(f[1])

"""
Duke14   9895    8
Emory27      7460    8
Indiana69    29747   8
Michigan23   30147   6
Tulane29     7752    8
UCLA26   20467   8
UPenn7   14916   8
Vermont70    7324    6
WashU32      7755    8
"""
## Michigan23   30147   6
# i = 36
counter = 0
Better = Vector{Int64}()
P1 = plot(grid = false)
Densities = zeros(100,3)
for i = 1:100
    global counter
graph = graphs[i]
F = matread(homedir()*"/data/Facebook100/$graph.mat")
A = F["A"]
local_info = round.(Int64,F["local_info"])

n = size(A,1)
M = matread("fb_output/$(graph)_output_pnear1.mat")
P = vec(M["P"])
Ssets = M["Ssets"]
Times = M["Times"]
Ranks = M["Ranks"]
Objectives = M["Objectives"]

Sizes = vec(sum(Ssets,dims = 1))
# ch = changetracker2(Ssets,3)
# plot(P[1:end],ch)

# for l = 1:6
#     L = local_info[:,l]
#     println()
#     println("Label $l")
#     for i = 1:8
#         S = findall(x->x>0,Ssets[:,i])
#         yS = L[S]
#         # As = A[S,S]
#         D =  countmap(yS)
#         Cats = topk(D,4)
#         # print("$(P[i])")
#         for y = Cats
#             ns = length(findall(x->x==y,yS))
#             print(" $ns \t")
#         end
#         println("")
#     end
# end


# Rich club test
jj = length(P)
degs = zeros(jj)
mx = zeros(jj)
vari = zeros(jj)
meds = zeros(jj)
mins = zeros(jj)

for i = 1:jj
    S = findall(x->x>0,Ssets[:,i])
    yS = L[S]
    As = A[S,S]
    ns = length(S)
    ds = vec(round.(Int64,sum(As,dims = 2)))
    # println("$(P[i]) \t $ns")
    pm = sortperm(vec(ds),rev = true)
    # @show ds[pm[1:10]]
    # pm2 = sortperm(vec(ds))
    # @show ds[pm2[1:10]]
    degs[i] = mean(ds)

    meds[i] = StatsBase.median(ds)
    mx[i] = maximum(ds)
    vari[i] = StatsBase.var(ds)
    mins[i] = minimum(ds)
end
what, wh = findmax(degs)
Densities[i,:] = degs
# @show degs
if wh != 2
    println("$i $graph")
    counter += 1
    push!(Better,i)
    plot!(P1,P,degs/maximum(degs),legend = false,color = :green, linewidth = 2)
else
    plot!(P1,P,degs/maximum(degs),legend = false,color = :gray, alpha = 0.5)
end

end

plot!(P1,grid = false) #ylim = [.95,1])
# savefig("oneat/$(graph)_meandeg.pdf")

# % Cat1 = local_info(:,1); % student-faculty flag
# % Cat2 = local_info(:,2); % gender
# % Cat3 = local_info(:,3); % major
# % Cat4 = local_info(:,4); % 2nd major
# % Cat5 = local_info(:,5); % dorm/residence
# % Cat6 = local_info(:,6); % Year
# % Cat7 = local_info(:,7); % high school

## count

D =  countmap(local_info[:,5])

function topk(D,top)
    K = keys(D)
    k = maximum(K)
    E = zeros(k)
    for key in K
        if key > 0
            E[key] = D[key]
        end
    end

    pm = sortperm(E, rev = true)

    if length(pm) <= top
        return pm
    else
        return pm[1:top]
    end

end
