f = readlines(homedir()*"/data/Facebook100/Facebook_Sets.txt")
graphs = split(f[1])
include("pdensity_algorithms.jl")

Ns = Vector{Int64}()
P1 = plot(title = "Runtimes",grid = false,xaxis = "n",)
for i = 7:length(graphs)
    graph =graphs[i]
    F = matread(homedir()*"/data/Facebook100/$graph.mat")
    A = F["A"]
    n = size(A,1)
    P = collect(0.5:0.5:4)
    # M = matwrite("fb_output/$(graph)_output.mat"
    #
    # Ssets = M["Ssets"]
    # Times = M["Times"]
    # Ranks = M["Ranks"]
    # Objectives = M["Objectives"]

    push!(Ns,n)
    # Runtimes, just a dot on the screen


end


## special functions
function isspecial_1(Sizes,cutoff)

    for i = 2:7
        if Sizes[i] > cutoff*Sizes[i-1] && Sizes[i] > cutoff*Sizes[i+1]
            return true, i
        end
    end
    if cutoff*Sizes[8] < Sizes[7]
        return true, 8
    end

    return false, 0

end

function isspecial_2(Sizes,cutoff)

    for i = 2:7
        if Sizes[i] > Sizes[i-1] + cutoff && Sizes[i] > Sizes[i+1] + cutoff
            return true, i
        end
    end
    if 2*cutoff + Sizes[8] < Sizes[7]
        return true, 8
    end

    return false, 0

end

function PRF(Target,Returned)

    if length(Returned) == 0
        pr = 0; re = 0; F1 = 0
    else
        TruePos = intersect(Returned,Target)
        pr = length(TruePos)/length(Returned)
        re = length(TruePos)/length(Target)
        F1 = 2*(pr*re)/(pr+re)

        if length(TruePos) == 0
            F1 = 0
        end
    end

    return pr, re, F1

end

function changetracker(Sets)
    changes = zeros(7)
    for i = 2:8
        pr, re, f1 = PRF(findall(x->x>0,Sets[:,i]),findall(x->x>0,Sets[:,i-1]))
        changes[i-1] = f1
    end
    return changes
end

function changetracker2(Sets,v)
    changes = zeros(8)
    S1 = findall(x->x>0,Sets[:,2])
    for i = 1:8
        pr, re, f1 = PRF(S1,findall(x->x>0,Sets[:,i]))
        if v == 1
            changes[i] = f1
        elseif v == 2
            changes[i] = pr
        else
            changes[i] = re
        end
    end
    return changes
end

## Just on result

P1 = plot(grid = false, legend = false)
P2 = plot(grid = false, legend = false)
R = plot(grid = false, legend = false, xlabel = "n", ylabel = "Runtime (s)")
counter = 0

for i = 1:100
    global counter
    thresh = 10000
    ms = 4
    lw = 1.5
graph =graphs[i]
F = matread(homedir()*"/data/Facebook100/$graph.mat")
A = F["A"]
n = size(A,1)
P = collect(0.5:0.5:4)
M = matread("fb_output/$(graph)_output.mat")

Ssets = M["Ssets"]
Times = M["Times"]
Ranks = M["Ranks"]
Objectives = M["Objectives"]

Sizes = vec(sum(Ssets,dims = 1))
if n > thresh
    counter += 1
    sp, wh = isspecial_1(Sizes,3)
    if ~sp
        plot!(P1,P,Sizes,color = :gray, alpha = 0.5, xlabel = "p",ylabel = "n")
    else
        plot!(P1,P,Sizes,markershape = :circle, color = :green,
        markercolor = :green, markersize = ms,markerstrokewidth = 0,
        xlabel = "p",ylabel = "|S|",linewidth = lw)
        println("$graph \t $n \t $wh")
    end
else
    sp, wh = isspecial_2(Sizes,1000)
    if ~sp
        plot!(P2,P,Sizes,color = :gray, alpha = 0.5, xlabel = "p",ylabel = "n")
    else
        plot!(P2,P,Sizes,markershape = :circle, color = :green,
        markercolor = :green, markersize = ms,markerstrokewidth = 0,
        xlabel = "p",ylabel = "|S|",linewidth = lw)
        println("$graph \t $n \t $wh")
    end
end

scatter!(R,[n],[Times[1]], color = :blue,markerstrokecolor = :blue)
scatter!(R,[n],[Times[2]], color = :red,markerstrokecolor = :red)
scatter!(R,vec([n n n n n n]),Times[3:end], color = :gray, markerstrokecolor = :gray)
end



## Plot figures
R
savefig("fb_figures/Facebook_runtimes.pdf")


##  Try something else


P1 = plot(grid = false, legend = false)
P2 = plot(grid = false, legend = false)
counter = 0
Spec = Vector{Int64}()
for i = 1:100
    global counter, lab
    thresh = 10000
    ms = 4
    v = 2
    if v == 1
        lab = "F1"
    elseif v == 2
        lab = "precision"
    else
        lab = "recall"
    end
    lw = 1.5
graph =graphs[i]
F = matread(homedir()*"/data/Facebook100/$graph.mat")
A = F["A"]
n = size(A,1)
P = collect(0.5:0.5:4)
M = matread("fb_output/$(graph)_output.mat")

Ssets = M["Ssets"]
Times = M["Times"]
Ranks = M["Ranks"]
Objectives = M["Objectives"]
ch = changetracker2(Ssets,v)
Sizes = vec(sum(Ssets,dims = 1))

if n > thresh
    counter += 1
    sp, wh = isspecial_1(Sizes,3)
    if ~sp
        plot!(P1,P,ch,color = :gray, alpha = 0.5, xlabel = "p",ylabel = lab)
    else
        plot!(P1,P,ch,markershape = :circle, color = :green,
        markercolor = :green, markersize = ms,markerstrokewidth = 0,
        xlabel = "p",ylabel = "|S|",linewidth = lw)
        push!(Spec,i)
        println("$i $graph \t $n \t $wh")
    end
else
    sp, wh = isspecial_2(Sizes,1000)
    if ~sp
        plot!(P2,P,ch,color = :gray, alpha = 0.5, xlabel = "p",ylabel = lab)
    else
        push!(Spec,i)
        plot!(P2,P,ch,markershape = :circle, color = :green,
        markercolor = :green, markersize = ms,markerstrokewidth = 0,
        xlabel = "p",ylabel = "|S|",linewidth = lw)
        println("$graph \t $n \t $wh")
    end
end

end

# plot

plot!(P1)
savefig("fb_figures/Facebook_$(lab)_large.pdf")


plot!(P2)
savefig("fb_figures/Facebook_$(lab)_small.pdf")
## One graph
i = 3
graph =graphs[i]
F = matread(homedir()*"/data/Facebook100/$graph.mat")
A = F["A"]
n = size(A,1)
P = collect(0.5:0.5:4)
M = matread("fb_output/$(graph)_output.mat")

Ssets = M["Ssets"]
Times = M["Times"]
Ranks = M["Ranks"]
Objectives = M["Objectives"]

Sizes = vec(sum(Ssets,dims = 1))

ch = changetracker2(Ssets,3)

plot(P[1:end],ch)
