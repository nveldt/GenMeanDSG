using MAT

M = matread(homedir()*"/data/TripAdvisor-UIUC-hypergraphs/tripadvisor_H.mat")

H = M["H"]

Hall = M["H_all"]
w = M["weights"]

l_country = M["label_country"]


## Need to turn this into a graph

A = Hall'*Hall
n = size(H,2)
for i = 1:n
    A[i,i] = 0
end
A = sparse(A)
I,J,V = findnz(A)
delta = 0
inds = findall(x->x>delta,V)
As = sparse(I[inds],J[inds],ones(length(inds)),n,n)
length(As.nzval)/n^2
A = As


## run many
P = collect(0.5:0.5:4)
Ssets = zeros(n,length(P))
Times = zeros(length(P))
Ranks = zeros(n,length(P))
Objectives = zeros(n,length(P))
for i = 1:length(P)
    p = P[i]
    tic = time()
    S, objS, Objs, ranking = GenPeel(A,p)
    timers = time()-tic
    Times[i] = timers
    Ssets[S,i] .= 1
    Objectives[:,i] = Objs
    Ranks[:,i] = ranking
    nS = length(S)
    println("$p \t $nS \t $objS \t $timers")

    matwrite("Output2/tripadvisor_output.mat",Dict("Ssets"=>Ssets,"P"=>P,
            "Ranks"=>Ranks,"Times"=>Times,"Objectives"=>Objectives))
end

#
# ## run some algs
# P = [1 2 3 4 5]
# Ssets = zeros(n,length(P))
# include("pdensity_algorithms.jl")
# for i = 1:length(P)
#     p = P[i]
#     S, objS, Objs, ranking = GenPeel(A,p)
#     Ssets[S,i] .= 1
# end
#
# ## Late
# ptest = 1:.5:5
# objs = zeros(length(P),length(ptest))
# for i = 1:length(P)
#     for j = 1:length(ptest)
#         p = ptest[j]
#         Sp = findall(x->x>0,Ssets[:,i])
#         objs[i,j] = pdensityobj(A,Sp,p)
#     end
# end
#
# bests = vec(maximum(objs,dims = 1))
#
#
# plot(ptest,objs[1,:]./bests,label = "1",grid = false, legend = :bottomleft)
# plot!(ptest,objs[2,:]./bests,label = "2",xlabel = "p", ylabel = "approximation to best set found")
# plot!(ptest,objs[3,:]./bests,label = "3")
# plot!(ptest,objs[4,:]./bests,label = "4")
# plot!(ptest,objs[5,:]./bests,label = "5",title = gname)
#
# savefig("Figures/tripadvisor.pdf")
#
#
# ## just objs
#
# plot(ptest,objs[1,:],label = "1",grid = false, legend = :bottomleft)
# plot!(ptest,objs[2,:],label = "2",xlabel = "p", ylabel = "approximation to best set found")
# plot!(ptest,objs[3,:],label = "3")
# plot!(ptest,objs[4,:],label = "4")
# plot!(ptest,objs[5,:],label = "5",title = gname)
#
# savefig("Figures/tripadvisor_justobjs.pdf")
