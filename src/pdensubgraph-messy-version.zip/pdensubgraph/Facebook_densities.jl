f = readlines(homedir()*"/data/Facebook100/Facebook_Sets.txt")
graphs = split(f[1])
include("pdensity_algorithms.jl")

for i = 7:length(graphs)
    graph =graphs[i]
    F = matread(homedir()*"/data/Facebook100/$graph.mat")
    A = F["A"]
    n = size(A,1)
    P = collect(0.5:0.5:4)
    Ssets = zeros(n,length(P))
    Times = zeros(length(P))
    Ranks = zeros(n,length(P))
    Objectives = zeros(n,length(P))
    for i = 1:length(P)
        p = P[i]
        tic = time()
        S, objS, Objs, ranking = GenPeel(A,p)
        timers = time()-tic
        Times[i] = timers
        Ssets[S,i] .= 1
        Objectives[:,i] = Objs
        Ranks[:,i] = ranking
        nS = length(S)
        println("$graph $p \t $nS \t $objS \t $timers")
    end



    matwrite("fb_output/$(graph)_output.mat",Dict("Ssets"=>Ssets,"P"=>P,
            "Ranks"=>Ranks,"Times"=>Times,"Objectives"=>Objectives))
end
