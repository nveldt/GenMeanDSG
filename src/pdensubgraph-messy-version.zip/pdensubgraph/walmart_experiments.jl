using MAT

M = matread("Datasets/Walmart_H.mat")
H = M["H"]




## Need to turn this into a graph

A = H'*H
n = size(H,2)
for i = 1:n
    A[i,i] = 0
end
A = sparse(A)
I,J,V = findnz(A)
delta = 0
inds = findall(x->x>delta,V)
As = sparse(I[inds],J[inds],ones(length(inds)),n,n)
length(As.nzval)/length(A.nzval)
A = As

d = sum(A,dims = 2)

## run some algs
P = collect(0.5:0.5:3)
Ssets = zeros(n,length(P))
include("pdensity_algorithms.jl")
for i = 1:length(P)
    p = P[i]
    @time S, objS, Objs, ranking = GenPeel(A,p)
    Ssets[S,i] .= 1
    println("$p \t $nS \t $objS")
end



matwrite("walmart_sets.mat",Dict("Ssets"=>Ssets,"P"=>P))

## Late
ptest = 1:.5:5
objs = zeros(length(P),length(ptest))
for i = 1:length(P)
    for j = 1:length(ptest)
        p = ptest[j]
        Sp = findall(x->x>0,Ssets[:,i])
        objs[i,j] = pdensityobj(A,Sp,p)
    end
end

bests = vec(maximum(objs,dims = 1))


plot(ptest,objs[1,:]./bests,label = "0.5",grid = false, legend = :bottomleft)
plot!(ptest,objs[2,:]./bests,label = "1",xlabel = "p", ylabel = "approximation to best set found")
plot!(ptest,objs[3,:]./bests,label = "1.5")
plot!(ptest,objs[4,:]./bests,label = "2")
plot!(ptest,objs[5,:]./bests,label = "2.5", title = "")
plot!(ptest,objs[6,:]./bests,label = "3", title = "")

savefig("Figures/walmart.pdf")





## Explore relationship with location metadata

S1 = findall(x->x>0,Ssets[:,1])
S2 = findall(x->x>0,Ssets[:,2])
S3 = findall(x->x>0,Ssets[:,3])
S4 = findall(x->x>0,Ssets[:,4])
S5 = findall(x->x>0,Ssets[:,5])


L3 = L[S1,1]

L3un = unique(L3)

city[L3un]


for i = 2:5
    Snew = findall(x->x>0,Ssets[:,i])
    Sold = findall(x->x>0,Ssets[:,i-1])

    justOld = length(setdiff(Sold,Snew))
    justNew = length(setdiff(Snew,Sold))
    both = length(intersect(Sold,Snew))
    println("$justOld \t $justNew \t $both")
end


## Plot?

S = S4
scatter(xy[S,1],xy[S,2], color = :green, grid = false, axis = false,
    markersize = 3,legend = false)
