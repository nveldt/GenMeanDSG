"""
Experiment One:

See how well our approximation algorithm does compared to the optimal solution on
smallish datasets.

We first solve the objective optimally using repeated submodular minimization.

We then check how good results are for our approximation algorithm,
    and compare the approximation ratio
"""

datasets = ["karateA","dolphinsA","polbooksA","adjnounA","lesmisA","BuckGraph","jazzA","footballA","Netscience"]


j = 1

graph = datasets[j]
for p = 1:0.5:5.0

    if p == floor(p)
        p = round(Int64,p)
    end
    M = matread("Output/$(name)_$(p)_0.1.mat")

    Svecs = M["Svecs"]
    check = M["check"]
    S = M["S"]
    timer = M["timer"]
    pmdensity = (M["pmdensity"])^(1/p)
    Densities = M["Densities"]
    timeout = M["timeout"]
    p = Float64(p)
    nS = length(S)
    if check != 1
        println("NoCheck $name \t $p \t $check \t $timeout \t $timer \t $pmdensity \t $nS")
    end
    if ~isincreasing(Densities)
        println("Densities: $name \t $p \t $check \t $timeout \t $timer \t $pmdensity \t $nS")
        @show Densities
    end
    println("$name \t $p \t $check \t $timeout \t $timer \t $pmdensity \t $nS")

end
