## Load in data, check what turned out

function isincreasing(D)
   for i = 2:length(D)
     if D[i] < D[i-1]
       return false
     end
   end
   return true
 end
using MAT
name = "Netscience"
name = "dolphinsA"
graphs = ["lesmisA","dolphinsA","karateA","polbooksA","adjnounA","footballA","jazzA","Netscience"];

for name = graphs
for p = 1:0.5:5.0

    if p == floor(p)
        p = round(Int64,p)
    end
    M = matread("Output/$(name)_$(p).mat")

    Svecs = M["Svecs"]
    check = M["check"]
    S = M["S"]
    timer = M["timer"]
    pmdensity = (M["pmdensity"])^(1)
    Densities = M["Densities"]
    y = M["y"]
    looped = M["looped"]
    timeout = M["timeout"]
    p = Float64(p)
    nS = length(S)
    if check != 1
        println("NoCheck $name \t $p \t $check \t $timeout \t $timer \t $pmdensity \t $nS")
    end
    if ~isincreasing(Densities)
        println("Densities: $name \t $p \t $check \t $timeout \t $timer \t $pmdensity \t $nS")
        @show Densities
    end
    println("$name \t $p \t $check \t $timeout \t $timer \t $pmdensity \t $nS")

end
end
