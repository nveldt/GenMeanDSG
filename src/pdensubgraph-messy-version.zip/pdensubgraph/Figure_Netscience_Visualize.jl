using SparseArrays
include("displaygraph.jl")

name = "Netscience"
P = Vector{Plots.Plot{Plots.GRBackend}}()
D = matread(homedir()*"/data/Graph-Collections/Graphs/$(name)_xy.mat")
A = D["A"]
xy = D["xy"]

ps = 1:0.5:5.0
for ip = 1:9
    p = ps[ip]

    if p == floor(p)
        p = round(Int64,p)
    end
M = matread("Output/$(name)_$(p).mat")
Svecs = M["Svecs"]
check = M["check"]
S = round.(Int64,M["S"])
timer = M["timer"]
pmdensity = (M["pmdensity"])^(1)
Densities = M["Densities"]
y = M["y"]
looped = M["looped"]
timeout = M["timeout"]
p = Float64(p)
nS = length(S)
# Load graph


f = display_graph(A,xy,.8)
scatter!(f,[xy[S,1]],[xy[S,2]], color = :blue,markersize = 3, title = "p = $p")
push!(P,f)
savefig("Figures/$(name)_$(p).pdf")

end


## this

l = @layout [a b; c d]
plot(P[1], P[2], P[3], P[4], layout = l)

savefig("Figures/netscience_plots.pdf")
