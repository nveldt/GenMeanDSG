graphs = {'lesmisA','dolphinsA','karateA','polbooksA'};
graphs = {'adjnounA','footballA','jazzA','Netscience','emailA','Amherst41'};

name = 'dolphinsA';

name = 'email'
load(strcat('~/data/Graph-Collections/Graphs/',name,'.mat'))
addpath('../../')

n = size(A);
issymmetric(A)


p = 1.5;

tic
y = -pi;
alpha = 16;
runs = 1;
timeout = 0;
        

%% Run

F = sfo_fn_pdenalpha(A,alpha,p);
S = sfo_min_norm_point(F,1:n);
y = pdenalpha(A,alpha,p,S);
pmdensity = pdensity(A,S,p);



%% 
y
pmdensity = pdensity(A,S,p)
alpha = pmdensity;
numel(S)
            
%%

while y < 0 
    last = y;
    F = sfo_fn_pdenalpha(A,alpha,p);
    S = sfo_min_norm_point(F,1:n);
    y = pdenalpha(A,alpha,p,S);
    pmdensity = pdensity(A,S,p);
    alpha = pmdensity-.5;
    if y == last
        break
    end
    runs = runs+1;
    if runs > 100
        timeout = 1;
        break
    end
end

% check (near) optimality
try

alpha = pmdensity+.5;
F = sfo_fn_pdenalpha(A,alpha,p);
Scheck = sfo_min_norm_point(F,1:n);
check = 0;
if numel(Scheck) == 0
    check = 1;
end
catch
    check = 0;
end
timer = toc;
save(strcat('Output/',name,'_',num2str(p),'.mat'),'pmdensity','p','check','S','timer','n','timeout')


%%
% 
% name = 'Amherst41';
% load(strcat('~/data/Graph-Collections/Graphs/',name,'.mat'))
% size(A)

%save('~/data/Graph-Collections/Graphs/polblogsA.mat','A'