load(strcat('../../Email.mat'))
A = A-diag(diag(A));

A = spones(A);

%%

addpath('../../')
n = size(A,1);
name = 'Email1003';
er = 0.01;
per = 1-er;

for p = 1.5
    
%     try
        tic
        y = -pi;
        alpha = 445;
        runs = 1;
        timeout = 0;
        looped = 0;
        Svecs = zeros(n,1);
        Densities = [];
        
        while y < 0 
            last = y;
            F = sfo_fn_pdenalpha(A,alpha,p);
            S = sfo_min_norm_point(F,1:n);
            y = pdenalpha(A,alpha,p,S);
            pmdensity = pdensity(A,S,p);
            
            eS = zeros(n,1);
            eS(S) = 1;

            alpha = pmdensity-1;
           
            % normal way to exit
            if y == last
                break
            end
          
            % started looping back on old values
            if ismember(pmdensity,Densities)
                looped = 1;
                break
            else
                Svecs = [Svecs eS];
                Densities = [Densities; pmdensity];
            end
                
            % passed maxits
            if runs > 100
                timeout = 1;
                break
            end
            
            runs = runs+1;
        end

        % check (near) optimality
        try

        alpha = pmdensity + 1;
        F = sfo_fn_pdenalpha(A,alpha,p);
        Scheck = sfo_min_norm_point(F,1:n);
        check = 0;
        if numel(Scheck) == 0
            check = 1;
        end
        catch
            check = 0;
        end
        timer = toc;
        
        % The hope is that y is negative, looped = timeout = 0, and check =
        % 1. If not, some part of my grand plan went wrong. Not necessarily
        % terrible, but maybe worth checking
        save(strcat('Output/',name,'_',num2str(p),'_tol_1_.mat'),'pmdensity','p','check','S','timer','n','timeout','looped','Svecs','Densities','y')
%     catch
%         fprintf('nope\n')
%     end
end
