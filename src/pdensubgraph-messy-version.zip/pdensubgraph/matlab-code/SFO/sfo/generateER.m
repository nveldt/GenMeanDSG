function B = generateER(s,in)

Bt = spones(triu(sprand(s,s,in)));
B = Bt+Bt';
B = B-diag(diag(B));


end