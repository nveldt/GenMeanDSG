%% Rich club synthetic
s = 25;
r = 3;
er = 0.0;
n = 4*s;
t = zeros(n);
in = .2;
A = sparse(n,n); 

truth = zeros(n,1);
for i = 1:4
    set = (i-1)*s+1:i*s;
    if i == 1
        A(set,set) = generateER(s,in+.2);
    else
        A(set,set) = generateER(s,in);
    end
    truth(set) = i;
end

noise = generateER(n,er);


% generate edges for the rich club
rin = .5;
R = generateER(r*4,rin);
club = [];
for i = 1:4
    start = (i-1)*s+1;
    set = (start:start+r-1)';
    club = [club; set];
end


A(club,club) = R;
% A = A+ noise;
spy(A)

ec = zeros(n,1);
ec(club) = 1;
cpn = find(spones(A*ec + ec));
length(cpn)

%% What does optimal p do?
p = 2;

tic
y = -pi;
alpha = 1;
runs = 1;
timeout = 0;
looped = 0;
Svecs = zeros(n,1);
Densities = [];

while y < 0 
    last = y;
    F = sfo_fn_pdenalpha(A,alpha,p);
    S = sfo_min_norm_point(F,1:n);
    y = pdenalpha(A,alpha,p,S);
    pmdensity = pdensity(A,S,p);

    eS = zeros(n,1);
    eS(S) = 1;

    alpha = pmdensity-1;

    % normal way to exit
    if y == last
        break
    end

    % started looping back on old values
    if ismember(pmdensity,Densities)
        looped = 1;
        break
    else
        Svecs = [Svecs eS];
        Densities = [Densities; pmdensity];
    end

    % passed maxits
    if runs > 100
        timeout = 1;
        break
    end

    runs = runs+1;
end

length(S)

