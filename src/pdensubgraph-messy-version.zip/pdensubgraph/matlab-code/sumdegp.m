function sdp = sumdegp(A,S,p)
% Compute the p-density of a subgraph, the average of the pth power of the
% degrees

As = A(S,S);
ds = sum(As,2);

sdp = full(sum(ds.^p));

end