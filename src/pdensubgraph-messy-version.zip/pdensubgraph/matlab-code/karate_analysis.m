%% Load the graph visualization
fileID = fopen('karate_layout1.gexf','r');

A = fscanf(fileID,'%s');
fclose(fileID)
IDloc = strfind(A,'nodeid');
viz_loc = strfind(A,'label');
xloc = strfind(A,'positionx="');
yloc = strfind(A,'"y="');
yend = strfind(A,'"></viz:position>');

xy = zeros(1,2);
for i = 1:numel(IDloc)
    id = str2num(A(IDloc(i)+8:viz_loc(i)-2));
    xcoord = str2num(A(xloc(i)+11:yloc(i)-1));
    ycoord = str2num(A(yloc(i)+4:yend(i)-1));
    xy(id,:) = [xcoord,ycoord];
end

addpath('~/data/Graph-Collections/Graphs/')
addpath('~/dev/MakeFigures/')
addpath('~/dev/pprpush/')

n = size(A,2);
d = sum(A,2);
lw = .5;
ms = 50;
scol = 'r';
sms = 38; % set marker size

%% Make smaller
load karate_truth
load Karate
d = full(sum(A,2));

[p,w] = sort(-d);
keep = w(1:20);
A = A(keep,keep);
xy = xy(keep,:);

%% Plot

addpath('~/data/Graph-Collections/Graphs/')
addpath('~/dev/MakeFigures/')
n = size(A,2);
d = sum(A,2);
lw = .5;
ms = 80;
scol = 'r';
sms = 70; % set marker size

figure(1); clf;
[px,py] = gplot(A,xy);
grayscale = .4;
plot(px,py,'.-','LineWidth',lw,'MarkerSize',ms,'Color','k');
hold on
R = find(c ==1);
%plot(xy(R,1),xy(R,2),'.','MarkerSize',sms,'Color','r');
plot(px,py,'.','LineWidth',lw,'MarkerSize',sms,'Color',[1 1 .9]);
hold on
n = size(A,1);
epsi = 0;
for i = 1:n
    text(xy(i,1)-epsi,xy(i,2),num2str(i),'color','k','FontSize',14,'HorizontalAlignment','center')
end
%axis tight
axis off
%axis square
set_figure_size([2.25*2.5,1.75*2.5]);
print(gcf,sprintf('karate-pic.eps'),'-depsc2');

%% The laplacian
d = full(sum(A,2));
D = diag(d);
L = full(D-A);
n = 10;
for i = 1:n
    fprintf('\n')
    for j = 1:n-1
        fprintf('%d & ',L(i,j))
    end
     fprintf('%d \\\\ ',L(i,n))
end

%% Fiedler value

[V,D] = eigs(L,20);
v2 = V(:,19);
fprintf('\n')
for j = 1:20
    fprintf('%.2f & ',v2(j))
end
fprintf('\n')

