function overds = logden(A,S)

As = A(S,S);
ds = sum(As,2)+1;

overds = sum(log(ds));

end