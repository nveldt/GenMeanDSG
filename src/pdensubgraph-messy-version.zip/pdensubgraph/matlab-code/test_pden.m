%% Checking submodularity of original thing

pdensity(A,S,p) + pdensity(A,T,p) >= pdensity(A,SnT,p) + pdensity(A,SuT,p)


pdensity(A,S,p) + pdensity(A,T,p);

pdensity(A,SnT,p) + pdensity(A,SuT,p);


%% Check simpler functions
load Karate
n = size(A,1);
n1 = 5;
n2 = 15;

p = 2;
tim = 1;
while true && tim < 10e3
tim = tim+1;
p1 = randperm(n);
p2 = randperm(n);
T = p1(1:n1);
S = p2(1:n2);

SnT = intersect(T,S);
SuT = union(T,S);


g = numel(S)^p + numel(T)^p <= numel(SuT)^p + numel(SnT)^p;
t = sumdegp(A,S,p) + sumdegp(A,T,p) - (sumdegp(A,SnT,p) + sumdegp(A,SuT,p));

if mod(tim,1000) == 0
    tim
end

if t > 0 %1e-14
    t = sumdegp(A,S,p) + sumdegp(A,T,p) - (sumdegp(A,SnT,p) + sumdegp(A,SuT,p))
    break
end

end


%% Check p = -1 case

load Karate
n = size(A,1);
n1 = 5;
n2 = 15;

p = 2;
tim = 1;
while true && tim < 100
tim = tim+1;
p1 = randperm(n);
p2 = randperm(n);
T = p1(1:n1);
S = p2(1:n2);

SnT = intersect(T,S);
SuT = union(T,S);


g = numel(S)^p + numel(T)^p <= numel(SuT)^p + numel(SnT)^p;
t = revden(A,S) + revden(A,T) - (revden(A,SnT) + revden(A,SuT));

if mod(tim,1000) == 0
    tim
end

if t > +1e-14
    S
    T
    revden(A,S) + revden(A,T)
    (revden(A,SnT) + revden(A,SuT))
    t = revden(A,S) + revden(A,T) - (revden(A,SnT) + revden(A,SuT))
    break
end

end

%sumdegp(A,S,p) + sumdegp(A,T,p) >= sumdegp(A,SnT,p) + sumdegp(A,SuT,p) 

%% Check p = 0 case

load Karate
n = size(A,1);
n1 = 5;
n2 = 15;

p = 2;
tim = 1;
while true && tim < 100
tim = tim+1;
p1 = randperm(n);
p2 = randperm(n);
T = p1(1:n1);
S = p2(1:n2);

SnT = intersect(T,S);
SuT = union(T,S);


g = numel(S)^p + numel(T)^p <= numel(SuT)^p + numel(SnT)^p;
t = logden(A,S) + logden(A,T) - (logden(A,SnT) + logden(A,SuT));

if mod(tim,1000) == 0
    tim
end

if t > +1e-14
    S
    T
    t = logden(A,S) + logden(A,T) - (logden(A,SnT) + logden(A,SuT))
    break
end

end

%% Checkirout
T = [34    32    16    10    29];
S = [32    34    22     6     4];
p = 1.1
t = sumdegp(A,S,p) + sumdegp(A,T,p) - (sumdegp(A,SnT,p) + sumdegp(A,SuT,p))


%% pairs

n = size(A,1);
for i = 1:n
    for j = i+1:n
        for k = j+1:n
            for z = k+1:n
            S = [i,z];
            T = [j,k];
            SnT = intersect(T,S);
            SuT = union(T,S);
            t = sumdegp(A,S,p) + sumdegp(A,T,p) <= sumdegp(A,SnT,p) + sumdegp(A,SuT,p);
            if ~t 
                i,j,k
                break
            end
            end
        end
    end
end