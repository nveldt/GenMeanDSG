function pden = pdensity(A,S,p)
% Compute the p-density of a subgraph, the average of the pth power of the
% degrees

As = A(S,S);
ds = sum(As,2);

pden = full(sum(ds.^p)/numel(S));

end