
x = 1000:10000;
x = 2:10;
y = log(x) - log(x-1);
    
plot(x,y,'r')
hold on
plot(x,1./(x-1),'b')
plot(x,(2*log(2))./x,'g')
hold off

% x = 2;
% while true
%     y = log(x) - log(x-1);
%     z = 1.1/y;
%     x = 2*x;
%     if y == NaN
%         break
%     end
%     if z < y
%         break
%     end
%     y,z,x
% end