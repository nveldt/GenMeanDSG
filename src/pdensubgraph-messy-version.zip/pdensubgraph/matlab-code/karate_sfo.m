graphs = {'Caltech36','Reed98','Simmons81'};
graphs = {'Erdos991A'};

graphs = {'lesmisA','dolphinsA','karateA','polbooksA','adjnounA','footballA','jazzA','Netscience'};

graphs = {'Netscience'};
for i = 1:numel(graphs)
name = graphs{i};
load(strcat('~/data/Graph-Collections/Graphs/',name,'.mat'))
%load(strcat('~/data/Facebook100/',name,'.mat'))

addpath('../../')
n = size(A,1);
if ~issymmetric(A)
    continue
end

tol = 10;
for p = 1.0:.5:5
    
    try
        tic
        y = -pi;
        alpha = 1;
        runs = 1;
        timeout = 0;
        looped = 0;
        Svecs = zeros(n,1);
        Densities = [];
        
        while y < 0 
            last = y;
            F = sfo_fn_pdenalpha(A,alpha,p);
            S = sfo_min_norm_point(F,1:n);
            y = pdenalpha(A,alpha,p,S);
            pmdensity = pdensity(A,S,p);
            
            eS = zeros(n,1);
            eS(S) = 1;

            alpha = pmdensity-tol;
           
            % normal way to exit
            if y == last
                break
            end
          
            % started looping back on old values
            if ismember(pmdensity,Densities)
                looped = 1;
                break
            else
                Svecs = [Svecs eS];
                Densities = [Densities; pmdensity];
            end
                
            % passed maxits
            if runs > 100
                timeout = 1;
                break
            end
            
            runs = runs+1;
        end

        % check (near) optimality
        try

        alpha = pmdensity+tol;
        F = sfo_fn_pdenalpha(A,alpha,p);
        Scheck = sfo_min_norm_point(F,1:n);
        check = 0;
        if numel(Scheck) == 0
            check = 1;
        end
        catch
            check = 0;
        end
        timer = toc;
        
        % The hope is that y is negative, looped = timeout = 0, and check =
        % 1. If not, some part of my grand plan went wrong. Not necessarily
        % terrible, but maybe worth checking
        save(strcat('Output/',name,'_',num2str(p),'_',num2str(tol),'.mat'),'pmdensity','p','check','S','timer','n','timeout','looped','Svecs','Densities','y')
    catch
        fprintf('nope\n')
    end
end
end

%%
name = 'Roget';
name = 'Erdos991'
load(strcat('~/data/Graph-Collections/Graphs/',name,'.mat'))
size(A)
A = Problem.A;
save(strcat('~/data/Graph-Collections/Graphs/',name,'A.mat'),'A')