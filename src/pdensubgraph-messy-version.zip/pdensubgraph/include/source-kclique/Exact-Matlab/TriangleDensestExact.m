function [Res, opt] = TriangleDensestExact(A)


%addpath('C:\Users\tsourolampis\Documents\SVN-repos\ZXC103-SVN\ICERM-Spring14\Projects\Triangle-Density\Code\Parametric-Max\maxflow')

n = length(A);
t = counttriangles(A);
t = sum(full(t))/3;
    
low = t/n;  % lower bound = the whole graph
high = (n-1)*(n-2)/6; % upper bound = {n choose 3}/n
topt=0;
opt = [];
triangleden = -10; 

while( low+1/n^2<= high)    
    fprintf('Current low high are %f,%f\n',low,high);
    alpha = (low+high)/2;
    Network = TriangleMaxFlowNetwork(A, alpha);
    T=[Network(1,2:end-1)', Network(2:end-1,end)];
    T=sparse(T);
    B=sparse(Network(2:end-1,2:end-1));
    [flow,cut] = maxflow( B ,T);
    S = find(cut==0) ;
    Sprime = intersect(S,1:n);
    A1 = Sprime; 
    A2 = setdiff(1:n,A1); 
    B1 = intersect(S,n+1:n+t);
    B2 = setdiff(n+1:n+t,B1);
    if(length(Sprime)==0)
        high = alpha;        
    else
        low   = alpha;
        X     = A(Sprime,Sprime);
        myden = trace(X^3)/(6*length(Sprime));
        if(  myden > triangleden) 
            triangleden = myden;
            opt = Sprime;
            %fprintf('Triangle density now %f\n',triangleden);
            topt=myden*6*length(Sprime);
        end
    end
end



eS2 = nnz( A(opt,opt) );
s=length(opt);
Res.S = s; 
Res.avgTrianges= 3*triangleden; 
Res.triangleDensity = topt/(s*(s-1)*(s-2));
Res.avgDegree = eS2/s;
Res.edgeDensity = eS2/(s*(s-1));
subgraph=opt;
Res.subgraph=subgraph;
