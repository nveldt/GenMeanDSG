%% Demo_Dense.m 
%% Author: Charalampos E. Tsourakakis, babis@seas.harvard.edu 

% you need to change appropriately these lines
%addpath(genpath('C:\Users\tsourolampis\Matlab\Parametric-Max\maxflow'))
%addpath('C:\Users\tsourolampis\Matlab\SFO\sfo')

%% load a small dataset, adjnoun.mat 

load adjnoun
A=Problem.A; 
A=A+A';
A(A>0)=1; 

%% Goldberg's exact algorithm 

[ResE] = GoldbergDensest(A);

%% Triangle densest using max flow 

[ResT] = TriangleDensestExact(A); 

%% Triangle densest using supermodularity


[ResTb] = TriangleDensestExactViaSubmod(A);