function t = counttriangles(A)


n = length(A);
t = zeros(1,n);

if(n <= 5000) % matlab is really bad with for loops
    t = diag(A^3)/2;
else
    for i = 1 : n
        neigh = find(A(i,:)>0);
        for j = 1 : length(neigh)-1
            for k = j+1 : length(neigh)
                if( A(neigh(j),neigh(k))==1  )
                    t(i)=t(i)+1;
                    % fprintf('Found triangle %d,%d,%d\n',i,neigh(j),neigh(k));
                end
            end
        end
    end
end