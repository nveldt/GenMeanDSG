function [Res, opt] = TriangleDensestExactViaSubmod(A)


% Author: Charalampos E. Tsourakakis, babis@seas.harvard.edu  
% Triangle densest subgraph using supermodular optimization. 
% Dependencies: Andreas Krause's submodular optimization software that can
% be found online at http://las.ethz.ch/sfo/

n = length(A); 
low = 0; 
high = (n-1)*(n-2)/6; % upper bound = {n choose 3}/n
topt=0;
opt = [];
triangleden = -10; 
%while( low+2/(n^2*(n-1))<= high)
 while( low+0.1<= high)
   
    fprintf('Current low high are %f,%f\n',low,high);
    alpha = (low+high)/2;
  
    
    S = TriangleDenseSubmodular(A,alpha);
    X=A(S,S);
    val = trace(X^3)/6-alpha*length(S);
    
    if( val>=0 &&~isempty(S))
        low = alpha; 
        myden = trace(X^3)/(6*length(S));
        if(  myden > triangleden) 
            triangleden = myden;
            opt = S;
            fprintf('Triangle density now %f\n',triangleden);
            topt=myden*6*length(S);
        end
    else
        high = alpha;  
    end
end


eS2 = nnz( A(opt,opt) );
s=length(opt);
Res.S = s; 
Res.avgTrianges= 3*triangleden; 
Res.triangleDensity = topt/(s*(s-1)*(s-2));
Res.avgDegree = eS2/s;
Res.edgeDensity = eS2/(s*(s-1));
subgraph=opt;
Res.subgraph=subgraph;