function Network = GoldbergNetwork(A, alpha) 

n = length(A);
Network = zeros(n+2,n+2);
Network(2:n+1,2:n+1)=A;
Network(2:n+1,n+2) = 2*alpha;
Network(1, 2:n+1 ) = sum(A); 
