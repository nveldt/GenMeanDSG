function Network = TriangleMaxFlowNetwork(A, alpha) 

% This function takes the adjacency matrix of an undirected and unweighted
% graph and returns the network that one has to run the max flow to find
% the triangle densest subgraph. 



n = length(A);
t = trace(A^3)/6;
B = zeros(n,t); %<- bipartite incidence matrix 

counter = 1; 
for i = 1 : n-2
    for j = i+1 : n-1
        for k = j+1 : n 
            if (A(i,j)==1 && A(j,k)==1 && A(i,k)==1 )
                B(i,counter)=1;
                B(j,counter)=1;
                B(k,counter)=1; 
                counter = counter+1; 
            end
        end
    end
end
if(counter~=t+1)
    error('debug')
end

C=[ sparse(zeros(n,n)) sparse(B); 2*sparse(B') sparse(zeros(t,t)) ]; 

%fprintf('Number of vertices %d\n',n);

Network = zeros(n+t+2,n+t+2);
Network(2:n+t+1,2:n+t+1)=C;

Network(2:n+1,n+t+2) = 3*alpha;
Network(1, 2:n+1 ) = sum(B,2)';