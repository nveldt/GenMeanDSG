function Res = TriangleDenseSubmodular(A,alpha)

V = 1:length(A);
F = triangles(A,alpha);
Res = sfo_min_norm_point(F,V);