function F = triangles(A,alpha)

fn = @(S) (-trace( A(S,S)^3)/6+alpha*length(S)); 
F = sfo_fn_wrapper(fn);
