function Res = GoldbergDensest(A)

A=sparse(A);
%addpath('C:\Users\tsourolampis\Documents\SVN-repos\ZXC103-SVN\ICERM-Spring14\Projects\Triangle-Density\Code\Parametric-Max\maxflow')
%[Res, subgraph, ordering, density]= CharikarApprox(A) ;
%fprintf('charikar average  degree %f\n',Res.avgDegree);

n = length(A); 
low =  nnz(A)/(2*n); 
high = (n-1)/2;

opt = [];
degreeden = -10; 
while( low+1/(n*(n-1))<= high)    
    fprintf('Current low high are %f,%f\n',low,high);
    alpha = (low+high)/2;
    Network = GoldbergNetwork(A, alpha);
    T=[Network(1,2:end-1)', Network(2:end-1,end)];
    T=sparse(T);  
    [flow,cut] = maxflow(A,T);
    S = find(cut==0) ;
    if(length(S)==0)
        high = alpha;        
    else
        low = alpha;
        X=A(S,S);
        myden = nnz(X)/(length(S));
        if(  myden > degreeden) 
            degreeden = myden;
            opt = S;
        end
    end
end

    
X = A(opt,opt); 
topt = trace(X^3)/6; 
eS2 = nnz(X);
s=length(opt);
Res.S = s; 
Res.avgTrianges=  3*topt/s; 
Res.triangleDensity = 6*topt/(s*(s-1)*(s-2));
Res.avgDegree = degreeden;
Res.edgeDensity = eS2/(s*(s-1));
Res.subgraph=opt;
