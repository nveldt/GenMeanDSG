using MAT

M = matread("Datasets/RestaurantHypergraph_H.mat")
# M2 = matread("yelp_restaurant_H.mat")
H = M["H"]

xy = M["latlong"]
L = M["locations"]

state = M["state_int2name"]          # column 3
city = M["city_int2name"]           # column 1
zipcode = M["zipcode_int2name"]     # column 2

ev = M["e_vegas"]

Z = findall(x->x>0,ev)

## Need to turn this into a graph

A = H'*H
n = size(H,2)
for i = 1:n
    A[i,i] = 0
end
A = sparse(A)
I,J,V = findnz(A)
delta = 1
inds = findall(x->x>delta,V)
As = sparse(I[inds],J[inds],ones(length(inds)),n,n)
length(As.nzval)/length(A.nzval)
A = As

## run some algs
# P = [1 2 3 4 5]
# Ssets = zeros(n,length(P))
# include("pdensity_algorithms.jl")
# for i = 1:length(P)
#     p = P[i]
#     @time S, objS, Objs, ranking = GenPeel(A,p)
#     Ssets[S,i] .= 1
# end
#
#
#
# matwrite("yelp_sets_newp.mat",Dict("Ssets"=>Ssets,"P"=>P))

## newp

P = collect(0.5:0.5:4)
Ssets = zeros(n,length(P))
Times = zeros(length(P))
Ranks = zeros(n,length(P))
Objectives = zeros(n,length(P))
for i = 1:length(P)
    p = P[i]
    tic = time()
    S, objS, Objs, ranking = GenPeel(A,p)
    timers = time()-tic
    Times[i] = timers
    Ssets[S,i] .= 1
    Objectives[:,i] = Objs
    Ranks[:,i] = ranking
    nS = length(S)
    println("$p \t $nS \t $objS \t $timers")

    matwrite("Output2/yelp_output.mat",Dict("Ssets"=>Ssets,"P"=>P,
            "Ranks"=>Ranks,"Times"=>Times,"Objectives"=>Objectives))
end



## Late
# ptest = 1:.5:5
# objs = zeros(length(P),length(ptest))
# for i = 1:length(P)
#     for j = 1:length(ptest)
#         p = ptest[j]
#         Sp = findall(x->x>0,Ssets[:,i])
#         objs[i,j] = pdensityobj(A,Sp,p)
#     end
# end
#
# bests = vec(maximum(objs,dims = 1))
#
#
# plot(ptest,objs[1,:]./bests,label = "1",grid = false, legend = :bottomleft)
# plot!(ptest,objs[2,:]./bests,label = "2",xlabel = "p", ylabel = "approximation to best set found")
# plot!(ptest,objs[3,:]./bests,label = "3")
# plot!(ptest,objs[4,:]./bests,label = "4")
# plot!(ptest,objs[5,:]./bests,label = "5", title = "")
#
# savefig("Figures/yelp.pdf")
#
#
# ## just objs
#
# plot(ptest,objs[1,:],label = "1",grid = false, legend = :bottomleft)
# plot!(ptest,objs[2,:],label = "2",xlabel = "p", ylabel = "approximation to best set found")
# plot!(ptest,objs[3,:],label = "3")
# plot!(ptest,objs[4,:],label = "4")
# plot!(ptest,objs[5,:],label = "5")
#
# savefig("Figures/yelp_justobjs.pdf")
#
#
#
#
# ## Explore relationship with location metadata
#
# T = matread("yelp_sets.mat")
#
# Ssets = T["Ssets"]
# P = [1 2 3 4 5]
#
# for i = 1:5
#     S = findall(x->x>0,Ssets[:,i])
#     SnZ =length(intersect(S,Z))
#     SuZ = length(union(S,Z))
#     @show SnZ, SuZ, length(S)
# end
#
# ## Other
#
# S1 = findall(x->x>0,Ssets[:,1])
# S2 = findall(x->x>0,Ssets[:,2])
# S3 = findall(x->x>0,Ssets[:,3])
# S4 = findall(x->x>0,Ssets[:,4])
# S5 = findall(x->x>0,Ssets[:,5])
#
#
# L3 = L[S1,1]
#
# L3un = unique(L3)
#
# city[L3un]
#
#
# for i = 2:5
#     Snew = findall(x->x>0,Ssets[:,i])
#     Sold = findall(x->x>0,Ssets[:,i-1])
#
#     justOld = length(setdiff(Sold,Snew))
#     justNew = length(setdiff(Snew,Sold))
#     both = length(intersect(Sold,Snew))
#     println("$justOld \t $justNew \t $both")
# end
#
#
# ## Plot?
#
# S = S5
# scatter(xy[S,1],xy[S,2], color = :green, grid = false, axis = true,
#     markersize = 3,legend = false, xlim = [33,37], ylim = [-117,-110])
