using MAT
using Plots

include("pdenalgs.jl")


## load something

gname = "polbooksA.mat"
# names = ["caHepPhA.mat","ca-AstroPhA.mat"]
#
#  gname = names
G = matread(homedir()*"/data/Graph-Collections/Graphs/"*gname)


## Load FB datasets
school = "Amherst41"
G = matread(homedir()*"/data/Facebook100/$school.mat")
A = G["A"]


## Run something
n = size(A,1)
P = [1 2 3 4 5]
Ssets = zeros(n,length(P))

for i = 1:length(P)
    p = P[i]
    S, objS = pgreedy(A,p)
    Ssets[S,i] .= 1
end


ptest = 1:.5:5
objs = zeros(length(P),length(ptest))
for i = 1:length(P)
    for j = 1:length(ptest)
        p = ptest[j]
        Sp = findall(x->x>0,Ssets[:,i])
        objs[i,j] = pgreedyobj(A,Sp,p)
    end
end

bests = vec(maximum(objs,dims = 1))


plot(ptest,objs[1,:]./bests,label = "1",grid = false, legend = :bottomleft)
plot!(ptest,objs[2,:]./bests,label = "2",xlabel = "p", ylabel = "approximation to best set found")
plot!(ptest,objs[3,:]./bests,label = "3")
plot!(ptest,objs[4,:]./bests,label = "4")
plot!(ptest,objs[5,:]./bests,label = "5",title = gname)

savefig("Figures/$(gname[1:end-4]).pdf")
