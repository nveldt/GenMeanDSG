using MAT
using Plots



## Load FB datasets
include("pdenalgs.jl")
schools = [ "Caltech36","Reed98","Simmons81", "Haverford76","Swarthmore42","USFCA72","Bowdoin47","Amherst41"]
for school = schools
G = matread(homedir()*"/data/Facebook100/$school.mat")
A = G["A"]

n = size(A,1)
P = [0.1 0.5 1 2 3 4]
Ssets = zeros(n,length(P))

for i = 1:length(P)
    p = P[i]
    S, objS = pgreedy2(A,p)
    Ssets[S,i] .= 1
end

ptest = vec([.1; collect(0.5:.5:4)])
objs = zeros(length(P),length(ptest))
for i = 1:length(P)
    for j = 1:length(ptest)
        p = ptest[j]
        Sp = findall(x->x>0,Ssets[:,i])
        objs[i,j] = pgreedyobj(A,Sp,p)
    end
end

bests = vec(maximum(objs,dims = 1))



plot(ptest,objs[1,:]./bests,label = "0.1",grid = false, legend = :bottomleft)
plot!(ptest,objs[2,:]./bests,label = "0.5",xlabel = "p", ylabel = "approximation to best set found")
plot!(ptest,objs[3,:]./bests,label = "1")
plot!(ptest,objs[4,:]./bests,label = "2")
plot!(ptest,objs[5,:]./bests,label = "3")
plot!(ptest,objs[6,:]./bests,label = "4",title = school)

savefig("Figures/$school.pdf")

end
