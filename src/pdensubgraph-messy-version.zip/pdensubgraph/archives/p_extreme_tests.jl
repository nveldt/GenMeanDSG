d = 100

b = log(d+1)/(log(d) - log(d-1))
den = (log(d) - log(d-1))
println("$d \t $b \t $den")
