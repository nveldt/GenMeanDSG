using SparseArrays
include("displaygraph.jl")
using MAT
using Arpack
name = "emailA"
D = matread(homedir()*"/data/Graph-Collections/Graphs/$(name).mat")
A = D["A"]

using MatrixNetworks
A,lccv = largest_component(A)

## stop
include("pdenalgs.jl")
xy_spec = getxyspectral(A)
f = display_graph(A,xy,.8)
f2 = scatter!(f,xy[:,1],xy[:,2],color = :black ,markerstrokecolor =:black)

## runit
name = "emailA"
P = Vector{Plots.Plot{Plots.GRBackend}}()
for k = 1:10; push!(P, plot()) end
ps = 1:0.5:5.0
ip = 4
p = ps[ip]

if p == floor(p)
    p = round(Int64,p)
end
M = matread("Output/$(name)_$(p).mat")
Svecs = M["Svecs"]
check = M["check"]
S = round.(Int64,M["S"])
timer = M["timer"]
pmdensity = (M["pmdensity"])^(1)
Densities = M["Densities"]
y = M["y"]
looped = M["looped"]
timeout = M["timeout"]
p = Float64(p)
nS = length(S)


## plotit
cl = :purple
scatter!(f,xy[S,1],xy[S,2],color =cl ,markerstrokecolor =cl)


## new set


f = display_graph(A,xy,.8)
scatter!(f,[xy[S,1]],[xy[S,2]], color = :blue,markersize = 5,title = "p = $p")
P[ip]=f
savefig("Figures/$(name)_$(p).pdf")



## this

l = @layout [a b; c d]
plot(P[1], P[2], P[3], P[4], layout = l)

savefig("Figures/karate_plots.pdf")
