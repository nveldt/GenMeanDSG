

function pgreedy_naive(A,p)
"""
Hasty code for generalized greedy peeling algorithm
"""
n = size(A,1)

S = collect(1:n)
sizeS = n

best = pgreedyobj(A,S,p)
Sbest = S
ranking = zeros(Int64,n)
for i = 1:n

    D = getdeltas_naive(A,S,p)
    m,local_j = findmin(D)
    j = S[local_j]
    ranking[i] = j
    S = setdiff(S,j)
    obj = pgreedyobj(A,S,p)
    if obj > best
        best = obj
        Sbest = S
    end
    # if obj == best
    #     println("Tied")
    # end

    # println("Removed $j, obj = $obj, $m")
end

return Sbest, best, ranking

end

function getdeltas_naive(A,S,p)

    As = A[S,S]
    nz = As.nzval
    cp = As.colptr
    row = As.rowval
    d = sum(As,dims = 1)
    D = zeros(length(S))
    for i = 1:length(S)

        D[i] = d[i]^p
        # Ni = findall(x->x>0,As[:,i])
        Ni = row[cp[i]:cp[i+1]-1]
        for j in Ni
            D[i] += d[j]^p - (d[j]-1)^p
        end
    end
    return D
end


function pgreedy(A,p)
"""
Smarter code for generalized greedy peeling algorithm
"""
n = size(A,1)

L = A               # local graph
S = collect(1:n)    # current set of nodes in local graph, in order
sizeS = n           # size of local graph

d = sum(L,dims = 1)

numerator = sum(d.^p)

bestObj = numerator/sizeS
bestS = S
ranking = zeros(Int64,n)

# remove nodes one at a time
for i = 1:n-1

    cp = L.colptr
    row = L.rowval

    # default to removing the 1st node remaining in the graph
    Delta = d[1]^p
    N1 = row[cp[1]:cp[1+1]-1] # neighborhood
    for k in N1
        Delta += d[k]^p - (d[k]-1)^p
    end
    remove = 1
    MinDelta = Delta

    # for each other node in remaining graph, compute change in
    # objective if it were removed
    for j = 2:sizeS
        Delta = d[j]^p
        Nj = row[cp[j]:cp[j+1]-1]
        for k in Nj
            Delta += d[k]^p - (d[k]-1)^p
        end
        if Delta < MinDelta
            MinDelta = Delta
            remove = j
        end
    end

    # remove the node you found with minimum delta.
    # S always stores global indices of nodes in L, the local graph
    ranking[i] = S[remove]
    Nr = row[cp[remove]:cp[remove+1]-1]

    # decrease the degree vector for neighbors of this node
    for k in Nr
        d[k] -= 1
    end

    # shrink the local graph, the set of global indices, and local degree vector
    if remove == 1
        inds = 2:sizeS
    else
        inds = [1:remove-1;remove+1:sizeS]
    end
    S = S[inds]
    L = L[inds,inds]
    d = d[inds]
    sizeS -= 1


    # see if the new subgraph has better density after removal
    numerator -= MinDelta
    obj = numerator/sizeS

    if obj > bestObj
        bestObj = obj
        bestS = S
    end

end

ranking[end] = S[1]

return bestS, bestObj, ranking

end

function pgreedy2(A,p)
"""
Smarter code for generalized greedy peeling algorithm
"""
n = size(A,1)
S = collect(1:n)    # current set of nodes in local graph, in order
sizeS = n           # size of local graph
d = sum(A,dims = 1)
numerator = sum(d.^p)

bestObj = numerator/sizeS
bestS = S
ranking = zeros(Int64,n)

cp = A.colptr
row = A.rowval
AdjList = Vector{Vector{Int64}}()
for i = 1:n
    push!(AdjList,row[cp[i]:cp[i+1]-1])
end

# remove nodes one at a time
for i = 1:n-1

    # AdjList is indexed globally
    # d is indexed globally (but entries decrease as nodes are removed)
    # S is the global indices of nodes, that still haven't been removed yet

    # default to removing the 1st node remaining in the graph
    Delta = d[S[1]]^p
    for k in AdjList[S[1]]
        Delta += d[k]^p - (d[k]-1)^p
    end
    remove = 1
    MinDelta = Delta

    # for each other node in remaining graph, compute change in
    # objective if it were removed
    for jj = 2:sizeS
        j = S[jj]
        Delta = d[j]^p
        for k in AdjList[j]
            Delta += d[k]^p - (d[k]-1)^p
        end
        if Delta < MinDelta
            MinDelta = Delta
            remove = jj
        end
    end

    # remove the node you found with minimum delta.
    # S always stores global indices of nodes in L, the local graph
    Sr = S[remove]
    ranking[i] = Sr

    # update the Adjacency List
    for k in AdjList[Sr]
        d[k] -= 1
        removej!(AdjList[k],Sr)
        # v1 = setdiff(AdjList[k],Sr)
        # @assert(AdjList[k] == v1)
    end
    AdjList[Sr] = Vector{Int64}()
    d[Sr] = 0

    # shrink the local graph, the set of global indices, and local degree vector
    # if remove == 1
    #     inds = 2:sizeS
    # else
    #     inds = [1:remove-1;remove+1:sizeS]
    # end
    # S = S[inds]
    deleteat!(S,remove)
    sizeS -= 1
    # @assert(length(S) == sizeS)

    # see if the new subgraph has better density after removal
    numerator -= MinDelta
    obj = numerator/sizeS

    # println("Removed $Sr, obj = $obj, $MinDelta")
    if obj > bestObj
        bestObj = obj
        bestS = copy(S)
    end

end

ranking[end] = S[1]
return bestS, bestObj, ranking

end


function pgreedy3(A,p,dicty = false)
"""
Smarter code for generalized greedy peeling algorithm
"""
n = size(A,1)
d = sum(A,dims = 1)
numer = sum(d.^p)
if dicty
    d2 = Dict{Int64,Int64}()
    for i = 1:n
        d2[i] = d[i]
    end
    d = d2
end
cp = A.colptr
row = A.rowval
tic = time()
AdjList = Vector{Vector{Int64}}()
for i = 1:n
    push!(AdjList,row[cp[i]:cp[i+1]-1])
end
D = zeros(n)
for i = 1:n
    D[i] = d[i]^p
    for k = AdjList[i]
        D[i] += d[k]^p - (d[k]-1)^p
    end
end
ranking = zeros(Int64,n)
H = MutableBinaryMinHeap(D)
Objs = zeros(n+1)
Objs[1] = (numer/n)^(1/p)
next = 2
denom = n-1
while ~isempty(H)
    # global numer, denom,next
    v, i = top_with_handle(H)
    # push!(order,i)
    ranking[next-1] = i
    pop!(H)
    Ni = AdjList[i]
    di = d[i]
    if di > 0
        dichange = di^p - (di-1)^p
        d[i] = 0
        numer -= di^p
        # Remove this from its neighbors list
        for nb = Ni
            removej!(AdjList[nb],i)                         # This is no longer a neighboring node, we're removed it
            db = d[nb]
            dbchange = -db^p + (db-1)^p
            Old = H[nb]                                     # previous value of D[nb]
            New = Old + dbchange - dichange    # new value now that node i is gone
            update!(H,nb,New)                               # update the heap
            D[nb] = New
            numer += dbchange # -(d[nb]^p-(d[nb]-1)^p)
            d[nb] -= 1                                      # decrease degree
        end

        # At this point, we have made all changes due to node i disappearing.
        # Now we need to account for changes in D/H
        # that are due to changes in the degree for i's neighbors
        for b = Ni
            db = d[b]
            dbchange = 2*db^p - (db-1)^p -(db+1)^p
            Nb = AdjList[b]
            for k = Nb
                update!(H,k,H[k]+dbchange)
            end
        end

    end
    Objs[next] = (numer/denom)^(1/p)
    denom -= 1
    next +=1
end
Objs[end] = 0

return Objs, ranking

end


function pgreedy4(A,p,dicty = false)
    """
    Smarter code for generalized greedy peeling algorithm
    """
    n = size(A,1)
    d = sum(A,dims = 1)
    numer = sum(d.^p)
    if dicty
        d2 = Dict{Int64,Int64}()
        for i = 1:n
            d2[i] = d[i]
        end
        d = d2
    end

    cp = A.colptr
    row = A.rowval
    AdjList = Vector{Vector{Int64}}()
    for i = 1:n
        push!(AdjList,row[cp[i]:cp[i+1]-1])
    end

    D = zeros(n)
    for i = 1:n
        D[i] = d[i]^p
        for k = AdjList[i]
            D[i] += d[k]^p - (d[k]-1)^p
        end
    end
    dorig = d

    # get the minimum value
    ranking = zeros(Int64,n)
    d = copy(dorig)
    H = MutableBinaryMinHeap(D)
    Objs = zeros(n+1)
    Objs[1] = numer/n
    next = 2
    denom = n-1
    while ~isempty(H)
        # global numer, denom,next
        v, i = top_with_handle(H)
        # push!(order,i)
        ranking[next-1] = i
        pop!(H)
        Ni = AdjList[i]
        di = d[i]
        if di > 0
            dichange = di^p - (di-1)^p
            d[i] = 0
            numer -= di^p
            # Remove this from its neighbors list
            for bi = 1:length(Ni)
                b = Ni[bi]
                db = d[b]
                # removej!(AdjList[b],i)                         # This is no longer a neighboring node, we're removed it
                Old = H[b]                                     # previous value of D[nb]
                New = Old - db^p + (db-1)^p - dichange    # new value now that node i is gone
                update!(H,b,New)                               # update the heap
                D[b] = New
                numer -= db^p-(db-1)^p

                # Now we need to account for changes in D/H
                # that are due to changes in the degree for i's neighbors
                dbchange = (db)^p - (db-1)^p
                Nb = AdjList[b]
                todel = 0
                for ki = 1:length(Nb)
                    k = Nb[ki]
                    if k == i
                        todel = ki
                    else
                        # Old = D[k]
                        Old = H[k]
                        # @assert(D[k] == Old1)
                        New = Old + (db-1)^p - (db-2)^p - dbchange
                        update!(H,k,New)
                        # D[k] = New
                    end
                end
                deleteat!(AdjList[b],todel)
                d[b] -= 1                                      # decrease degree
            end
        end
        Objs[next] = numer/denom
        denom -= 1
        next +=1
    end
    Objs[end] = 0

    return Objs, ranking

end

# remove element j from vector v, assuming that j appears exactly once
function removej!(v::Vector{Int64},j)
    for i = 1:length(v)
        if v[i] == j
            # v = v[1:i-1,i+1:end]
            deleteat!(v,i)
            return
        end
    end
end

function pgreedyobj(A,S,p)

    if length(S) == 0
        return 0
    else
        As = A[S,S]
        d = sum(As,dims = 1)

        return sum(d.^p)/length(S)
    end

end
