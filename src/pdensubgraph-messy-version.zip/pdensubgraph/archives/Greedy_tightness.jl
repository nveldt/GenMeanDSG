## Functions for understanding tight examples for greedy algorithm

p = 4

k = BigInt(2*round(Int64,p)^2)
n = BigInt(100*k^2)

# degrees in the generalized line graph
line_d = 2*k*ones(n)
for i = 1:k
    line_d[i] = k+i-1
    line_d[n-i+1] = k+i-1
end

F1 = sum(line_d.^p)/n
# F1 = (2k)^p
D1 = (2k)^p

# The clique graph with worse density, but greedy won't touch it
# it's a clique of size r+1
b = round(Int64,ceil((2k)/(p+1)^(1/p) + 1))
# r = 1
# while r^p + r*(r^p-(r-1)^p) < (2k)^p
#     # global r
#     r += 1
# end

r = b
F2 = r^p
D2 = r^p + r*(r^p - (r-1)^p)

ratio = (2k/r)^p

# What's the actual greedy algorithm approximation returned?
# The best will be before we delete anything
c = BigInt(n^2)
num = BigInt(c*r*r^p + sum(line_d.^p))
denom = BigInt(c*r + n)

Freal = (num/denom)
ratio =  Float64(round(F1/Freal,digits = 3))

print("")
println("$p \t $ratio")


## check approx

for p = 10:10:100
    f = (p+1)^(1/p)
    @show f, 1/f

end
