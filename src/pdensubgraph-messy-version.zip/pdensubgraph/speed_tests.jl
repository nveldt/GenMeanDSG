using MAT
using Plots



## load something

gname = "polbooksA.mat"
# gname = "KarateA.mat"
# names = ["caHepPhA.mat","ca-AstroPhA.mat"]
#
#  gname = names
G = matread(homedir()*"/data/Graph-Collections/Graphs/"*gname)
A = G["A"]

## Load FB datasets
include("pdenalgs.jl")
school = "Caltech36"
# school = "Amherst41"
# school = "Texas84"
#school = "Mich67"
G = matread(homedir()*"/data/Facebook100/$school.mat")
A = G["A"]
dor = vec(sum(A,dims = 2))
p = 3


## sho
n = size(A,1)
d = vec(round.(Int64,sum(A,dims = 1)))
numer = sum(d)

# save graph as adjacency list
cp = A.colptr
row = A.rowval
AdjList = Vector{Vector{Int64}}()
for i = 1:n
    push!(AdjList,row[cp[i]:cp[i+1]-1])
end

D = MutableBinaryMinHeap(d);



## p = 1
include("pdensity_algorithms.jl")
p = 1
Objs, ranking, degrees = SimplePeel(A)

density, w = findmax(Objs)
S = ranking[w:end]
degeneracy, w2 = findmax(degrees)
maxcore = ranking[w2:end]

As = A[maxcore,maxcore]
ds = sum(As,dims = 1)
minimum(ds)

## runit


tic = time()
S1, objS1,ranking = pgreedy_naive(A,p)
toc1 = time()-tic




# tic = time()
# S, objS,ranking = pgreedy(A,p)
# toc2 = time()-tic

## new

tic = time()
S, objS,ranking1 = pgreedy2(A,p)
toc3 = time()-tic

## k
include("pdenalgs.jl")
## newest
tic = time()
Objs, ranking = pgreedy3(A,p,true)
toc3 = time()-tic

## check

@show (objS)^(1/p), maximum(Objs)
## Check
n = size(A,1)
objs = zeros(n)
for i = 1:n
    objs[i] = pgreedyobj(A,ranking[i:end],p)
    # println("$i, $(ranking[i]), $obj")
end

scatter(1:n,objs,markersize=1, markerstrokecolor = :blue, markerstrokewidth = 0,markercolor = :blue)

## Profilers

@profiler S1, objS1,ranking1 = pgreedy_naive(A,p)
@profiler S, objS,ranking = pgreedy(A,p)
