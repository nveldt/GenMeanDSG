using SparseArrays
include("displaygraph.jl")
include("pdenalgs.jl")
using MAT
using Arpack
name = "emailA"
D = matread("email_xy.mat")
A = D["A"]
xy = D["xy"]
n = size(A,1)

## Email
D2 = matread("Email.mat")
A = D2["A"]



## get all
name = "emailA"

sets = zeros(n,4)
P = Vector{Plots.Plot{Plots.GRBackend}}()
for k = 1:10; push!(P, plot()) end
ps = 1:0.5:2.5
for ip = 1:4
p = ps[ip]

if p == floor(p)
    p = round(Int64,p)
end
M = matread("Output/$(name)_$(p).mat")
Svecs = M["Svecs"]
check = M["check"]
S = round.(Int64,M["S"])
timer = M["timer"]
pmdensity = (M["pmdensity"])^(1/p)
Densities = M["Densities"]
y = M["y"]
looped = M["looped"]
timeout = M["timeout"]
p = Float64(p)
nS = length(S)
sets[S,ip] .= 1
println("$name \t $p \t $check \t $timeout \t $timer \t $pmdensity \t $nS")

end


## later


C = vec(sum(sets,dims = 2))
keep = findall(x->x>0,C)
Ck = C[keep]
Ak = A[keep,keep]
xyk = xy[keep,:]
sk = sets[keep,:]
P = Vector{Plots.Plot{Plots.GRBackend}}()
for k = 1:10; push!(P, plot()) end
ps = 1:0.5:5.0
for ip = 1:4
    p = ps[ip]
    S = findall(x->x==ip,Ck)
    S = findall(x->x>0,sk[:,ip])
    if p == floor(p)
        p = round(Int64,p)
    end

f = display_graph(Ak,xyk,.8)
scatter!(f,[xyk[:,1]],[xyk[:,2]], color = :black,markerstrokecolor = :black,markersize = 4,title = "p = $p")
scatter!(f,[xyk[S,1]],[xyk[S,2]], color = :blue,markerstrokecolor = :blue,markersize = 5,title = "p = $p")
P[ip]=f
savefig("Figures/Email_Subgraph_$(p).pdf")

end
